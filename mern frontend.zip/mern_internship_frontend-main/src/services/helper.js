export const BASE_URL = "http://localhost:6010"
// export const BASE_URL = "https://mernappbackend.onrender.com"